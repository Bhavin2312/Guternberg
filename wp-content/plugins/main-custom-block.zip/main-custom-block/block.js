console.log("✅ block.js is loaded!");
