<?php
/**
 * Plugin Name: Main Custom Block
 * Description: A Gutenberg block that displays your homepage layout exactly in the editor.
 * Version: 1.0
 */

if (!defined('ABSPATH'))
    exit;

function mcb_register_block()
{
    // Register block editor script
    wp_register_script(
        'mcb-editor', // handle
        plugins_url('block.js', __FILE__), // path
        array('wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-block-editor'), // dependencies
        filemtime(plugin_dir_path(__FILE__) . 'block.js') // version (fixed path)
    );

    // Register frontend + editor styles
    wp_register_style(
        'mcb-style',
        plugins_url('style.css', __FILE__),
        array(),
        filemtime(plugin_dir_path(__FILE__) . 'style.css')
    );

    register_block_type('mcb/homepage-layout', array(
        'editor_script' => 'mcb-editor',
        'editor_style' => 'mcb-style',
        'style' => 'mcb-style',
        'render_callback' => 'mcb_render_block',
        'attributes' => array(
            'heroTitle' => array('type' => 'string', 'default' => 'Welcome to MyCMS'),
            'heroText' => array('type' => 'string', 'default' => 'Your easy-to-use content management system.'),
        )
    ));
}
add_action('init', 'mcb_register_block');

// Block render output
function mcb_render_block($attributes)
{
    ob_start();
    ?>
    <section class="hero">
        <div class="container">
            <h1><?php echo esc_html($attributes['heroTitle']); ?></h1>
            <p><?php echo esc_html($attributes['heroText']); ?></p>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
